'use client';

import * as React from 'react';

export default function Home() {
  return <h1>서브페이지</h1>;
}
